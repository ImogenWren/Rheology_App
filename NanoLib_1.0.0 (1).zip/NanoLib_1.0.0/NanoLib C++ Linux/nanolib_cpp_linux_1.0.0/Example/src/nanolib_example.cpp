
#include "nanolib_example_program.hpp"

int main() {
	
	NanoLibExampleProgram theProgram;

	return theProgram.run();
}
