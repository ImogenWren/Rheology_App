#pragma once

#include "nano_lib_accessor.hpp"
#include "nlc_export_import.hpp"

extern "C" NLC__EXPORT nlc::NanoLibAccessor *getNanoLibAccessor();