
# -*- coding: utf-8 -*-

__title = 'nanotec_nanolib_linux'
__description = 'Communication and controlling library for Nanotec motor controller.'
__url = 'http://nanotec.com'
__version = '1.0.0'
__build = 344
__author = 'Nanotec Electronic GmbH & Co. KG'
__author_email = 'support@nanotec.de'
__license = 'Creative Commons Attribution 3.0 Unported License. Creative Commons Attribution-NoDerivatives 4.0 International License.'
__copyright = 'Copyright 2019 Nanotec Electronic GmbH & Co. KG'
